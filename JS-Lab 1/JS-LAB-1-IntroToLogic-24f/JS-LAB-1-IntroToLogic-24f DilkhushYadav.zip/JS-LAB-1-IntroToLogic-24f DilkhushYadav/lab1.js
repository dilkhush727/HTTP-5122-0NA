// alert("Hello World");

// Assign name in string data type
var myName = "Dilkhush ";

// Assign age in number data type
var myAge = 28;

// number of days in a year
var numberOfDays = 365;

//  total of age multiplied by the number of days in the year
var totalDays = (myAge * numberOfDays);

// Message text to complete the message
var messageText = " days old… more or less.";

// alert(totalDays);

alert(myName + 'is ' + totalDays + messageText);